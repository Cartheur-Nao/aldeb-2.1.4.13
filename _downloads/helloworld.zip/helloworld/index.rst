Creating a simple remote module
===============================

:ref:`\<\< return to C++ examples<cpp-examples>`

This example shows how to create a module (here this is a very simple module
making the robot say "HelloWorld"), how to create bound methods that will be
accessible from the outside, and how to access this module from the outside.

.. toctree::
   :maxdepth: 2

   example
