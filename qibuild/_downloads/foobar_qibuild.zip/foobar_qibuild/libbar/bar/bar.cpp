#include <bar/bar.hpp>

int bar()
{
  return 0;
}
