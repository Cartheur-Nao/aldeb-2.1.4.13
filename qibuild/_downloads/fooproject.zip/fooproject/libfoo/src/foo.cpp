#include <foo/foo.hpp>
#include "foo_p.hpp"

int public_method()
{
  return private_method();
}


